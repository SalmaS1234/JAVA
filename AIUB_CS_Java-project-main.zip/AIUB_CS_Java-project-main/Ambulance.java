
package tfzfhms;

public interface Ambulance {
    void Ambulance_show();
}
