
package tfzfhms;

public interface Doctorinterfeces {
    public void Add_New_Doctor();
}
